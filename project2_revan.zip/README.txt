I had to put the entire folder I use for python work in this zip file since the pictures I added won't work if I put it in the designated 'images' folder I created for the game. Once inside the folder move to alien_invasion and there you'll find all the work for the project.

Controls:
Exit            - Esc
Move left       - Left Arrow
Move Right      - Right Arrow
Shoot bullets   - Space